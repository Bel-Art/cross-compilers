#ifndef __ASMSPARC_AUXVEC_H
#define __ASMSPARC_AUXVEC_H

#endif /* !(__ASMSPARC_AUXVEC_H) */

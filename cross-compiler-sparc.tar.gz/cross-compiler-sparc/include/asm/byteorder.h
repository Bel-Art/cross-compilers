#ifndef _SPARC_BYTEORDER_H
#define _SPARC_BYTEORDER_H

#include <linux/byteorder/big_endian.h>

#endif /* _SPARC_BYTEORDER_H */

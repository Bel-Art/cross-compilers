#ifndef ___ASM_SPARC_STATFS_H
#define ___ASM_SPARC_STATFS_H

#include <asm-generic/statfs.h>

#endif
